<?php
/**
 * @package zapier
 */
class ZapierSubscriptions extends xPDOSimpleObject {}
?>